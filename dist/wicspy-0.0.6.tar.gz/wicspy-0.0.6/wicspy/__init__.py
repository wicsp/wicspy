'''
Author: wicsp wicspa@gmail.com
Date: 2024-06-05 17:29:03
LastEditors: wicsp wicspa@gmail.com
LastEditTime: 2024-06-06 16:21:58
FilePath: /wicspy/wicspy/__init__.py
Description: 

Copyright (c) 2024 by wicsp, All Rights Reserved. 
'''
from .bark import *

__version__ = "0.0.6"
