<!--
 * @Author: wicsp wicspa@gmail.com
 * @Date: 2024-08-26 17:01:30
 * @LastEditors: wicsp wicspa@gmail.com
 * @LastEditTime: 2024-08-26 17:03:45
 * @FilePath: /wicspy/README.md
 * @Description: 
 * 
 * Copyright (c) 2024 by wicsp, All Rights Reserved. 
-->
# wicspy

# A python package for wicsp.
