'''
Author: wicsp wicspa@gmail.com
Date: 2024-06-18 19:12:15
LastEditors: wicsp wicspa@gmail.com
LastEditTime: 2024-06-18 19:12:27
FilePath: /wicspy/wicspy/timer.py
Description: 

Copyright (c) 2024 by wicsp, All Rights Reserved. 
'''
import timer
