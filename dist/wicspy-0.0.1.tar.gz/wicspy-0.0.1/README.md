<!--
 * @Author: wicsp wicspa@gmail.com
 * @Date: 2024-06-05 13:44:52
 * @LastEditors: wicsp wicspa@gmail.com
 * @LastEditTime: 2024-06-05 13:48:21
 * @FilePath: /wicspy/README.md
 * @Description: 
 * 
 * Copyright (c) 2024 by wicsp, All Rights Reserved. 
-->
A python package for wicsp.