'''
Author: wicsp wicspa@gmail.com
Date: 2024-06-05 13:44:37
LastEditors: wicsp wicspa@gmail.com
LastEditTime: 2024-06-05 16:40:29
FilePath: /wicspy/wicspy.py
Description: A Python package for wicsp.

Copyright (c) 2024 by wicsp, Licensed under the MIT license.
'''

__version__ = '0.0.2'

from bark import *